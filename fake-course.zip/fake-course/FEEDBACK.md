# Feedback

(suggested: Open this in Markdown Preview Mode. Command Palette > Markdown: Open Preview)

## Instructions

1. Go through [Module 1](./01-read-typescript/README.md)
2. (non-specific)
   1. Write down any thoughts you have (good, bad and ugly).
3. (specific)
   1. What do you think about the format? (short exercises, finding OSS code examples, running tests with shell script, etc)
   2. What do you think about the lesson length?
   3. What do you think about the lesson content? (any lingering questions?)
4. Anything else!

## How to share with me

I'm flexible! Whatever works best for you:

- [DM me](https://joeprevite.com/dm) your feedback
- email me: [joe@joeprevite.com](mailto:joe@joeprevite.com?subject=TS%20Course%20Feedback&body=Hey%20Joe!%0D%0A%0D%0AHere's%20the%20feedback%20I%20have%20for%20you%3A)
- send me a [gist](https://gist.github.com/)
