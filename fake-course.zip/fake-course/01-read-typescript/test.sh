#!/bin/sh
set -eu
# For coloring output
# https://stackoverflow.com/a/20983251/3015595
RED=$(tput setaf 1)
GREEN=$(tput setaf 2)
RESET=$(tput sgr0)
# Credit to this Stack Exchange answer for explaining this:
# https://unix.stackexchange.com/a/343974/363304
SUCCESS_CHECKMARK=$(printf '\342\234\224\n' | iconv -f UTF-8)
CROSS_MARK=$(printf '\342\235\214\n' | iconv -f UTF-8)

# We need to print messages to stderr
# when they're called by other functions
# this function makes it easier
# https://superuser.com/a/1320694/1240803
echo_in_background() {
  echo "$1" >&2
}

main() {
  local LESSON_NAME="Learn Parameter Type Annotations"

  if [ "$(verify_lesson_01 "$LESSON_NAME")" -eq 0 ]; then
    echo ""
    echo "$SUCCESS_CHECKMARK Lesson 1 Complete"
    mark_lesson_complete "$LESSON_NAME"
  else
    echo ""
    echo "$CROSS_MARK Lesson Incomplete"
    echo ""
    echo "Please finish all exercises"
    echo "and answer all questions"
    echo "in order to complete lesson"
  fi
}

verify_lesson_01() {
  # We have to put this at the start
  # because when we define our locals
  # it actually calls those functions
  # so this ensures the two echo lines
  # print before anything else.
  echo_in_background "Verifying Lesson: ${1:-"Learn Parameter Type Annotations"}"

  local EXERCISES_RESULTS=$(verify_exercises_01)
  local QUIZZ_RESULTS=$(verify_quiz_answers_01)

  if [ "$EXERCISES_RESULTS" -eq 0 ] && [ "$QUIZZ_RESULTS" -eq 0 ]; then
    echo 0
  else
    echo 1
  fi
}

verify_exercise_01_2() {
  # Find the block with the exercise
  local BLOCK=$(grep -A5 "2 - In The Wild" 01-parameter-types.md)
  # Check if it has a link
  local RESULT=$(echo "$BLOCK" | grep -c "Link:\s*https://.*")
  if [ "$RESULT" -eq 1 ]; then
    echo_in_background '2. PASS: Found link provided'
    echo 0
  else
    echo_in_background '2. FAIL: Missing link'
    echo 1
  fi
}

verify_exercise_01_3() {
  # Find the block with the exercise
  local BLOCK=$(grep -A7 "3 - Meta" 01-parameter-types.md)
  # Check if it has a link
  local RESULT=$(echo "$BLOCK" | grep -c "Link:\s*https://.*")
  if [ "$RESULT" -eq 1 ]; then
    echo_in_background "3. PASS: Found link provided"
    echo 0
  else
    echo_in_background '3. FAIL: Missing link'
    echo 1
  fi
}

verify_exercise_01_1() {
  # check for the parameter type
  # -c counts the number of occurrences
  local RESULT=$(grep -c "a: number, b: number" 01-parameter-types.md)

  if [ "$RESULT" -eq 1 ]; then
    # Credit: https://superuser.com/a/1320694/1240803
    echo_in_background '1. PASS: Found parameter type "a: number, b: number"'
    # 0 means true
    echo 0
  else
    echo_in_background '1. FAIL: Could not find parameter type "a: number, b: number"'
    echo 1
  fi
}

verify_quiz_answer_01() {
  local EXPECTED=$1
  # credit: https://linuxconfig.org/how-to-extract-a-number-from-a-string-using-bash-example
  local NUMBER=$(echo "$1" | grep -o -E '[0-9]+')
  local RESULT=$(grep -c "$EXPECTED" 01-parameter-types.md)
  # Changes A1: Yes to just Yes, the xargs removes whitespace
  local EXPECTED_PRETTY=$(echo "$EXPECTED" | cut -d ":" -f2 | xargs)

  if [ "$RESULT" -eq 1 ]; then
    echo_in_background "$NUMBER. PASS: Correct answer"
    echo 0
  else
    echo_in_background "$NUMBER. FAIL: The correct answer was '$EXPECTED_PRETTY'"
    echo 1
  fi
}

verify_exercises_01() {
  local EXERCISE_FILE_NAME="01-parameter-types.md"
  local TOTAL=3
  local RESULTS=0
  echo_in_background ""
  echo_in_background "Exercise results for $EXERCISE_FILE_NAME"

  for EXERCISE in verify_exercise_01_1 verify_exercise_01_2 verify_exercise_01_3
  do
    local RESULT=$($EXERCISE)
    if [ "$RESULT" -eq 0 ]; then
      ((RESULTS=RESULTS+1))
    fi
  done

  echo_in_background "Correct: $RESULTS/$TOTAL"

  if [ "$RESULTS" -eq "$TOTAL" ]; then
    echo 0
  else
    echo 1
  fi
}

verify_quiz_answers_01() {
  local EXERCISE_FILE_NAME="01-parameter-types.md"
  local TOTAL=3
  local RESULTS=0

  echo_in_background ""
  echo_in_background "Quiz results for $EXERCISE_FILE_NAME"

  for RESULT in $(verify_quiz_answer_01 "A1: Yes") $(verify_quiz_answer_01 "A2: :") $(verify_quiz_answer_01 "A3: string")
  do
    if [ "$RESULT" -eq 0 ]; then
      ((RESULTS=RESULTS+1))
    fi
  done

  echo_in_background "Correct: $RESULTS/$TOTAL"

  if [ "$RESULTS" -eq "$TOTAL" ]; then
    echo 0
  else
    echo 1
  fi
}

mark_lesson_complete() {
  local LESSON_NAME=$1
  # Credit: https://unix.stackexchange.com/a/295284/363304
  sed -i '' "/\[ \] $LESSON_NAME/ s/\[ \]/[x]/" README.md
}

main "$@"