# Module 1 - How to Read TypeScript

In this module, you will learn how to read TypeScript.

## Objectives

- [ ] Annotations
  - [ ] Learn Parameter Type Annotations
  - [ ] Learn Return Type Annotations
  - [ ] Learn Optional Types
- [ ] Declaration Files
  - [ ] Learn what they are
  - [ ] Learn where to find them

## Guide

Each file has the following components:

- lesson: the concept you're learning
- exercise: hands-on practice
- quiz: verify what you learned
- reflection: remember what you learn

You can verify your answers at the end by running `sh test.sh 01`.

To get started, head over to the first lesson [01-parameter-types.md](./01-parameter-types.md)
