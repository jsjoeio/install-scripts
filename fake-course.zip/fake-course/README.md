Used for testing purposes.
