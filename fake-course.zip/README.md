# TypeScript Course

Hello! This will eventually be the `README.md` for my upcoming TypeScript course.

## Follow Along

For updates, subscribe to this Telegram channel: https://t.me/jsjoeio_ts_course

## Want to let me know you tried this?

Tweet @ me! Use [this link](https://twitter.com/intent/tweet?text=Hey%20%40jsjoeio!%20I%20tried%20your%20CLI%20for%20your%20upcoming%20TypeScript%20course%20and%20it%27s%20awesome%20%F0%9F%9A%80%0A%0AFor%20others%20who%20want%20to%20check%20it%20out%2C%20here%20is%20a%20link%3A%0Ahttps%3A%2F%2Fgithub.com%2Fjsjoeio%2Fjp-courses-install)
