# Lesson: Parameter Type Annotations

Type annotations are where you, the developer, write out the expected type of a
value. In this case, we're looking at parameters. Parameters are the values
passed by and used in functions (sometimes used interchangeably with "arguments").

These must always be annotated because TypeScript can't (or doesn't) infer them.

```typescript
function helloWorld(name: string) {
  return `Hello, ${name}! —World`
}
```

In the example above, the parameter `name` is annotated by `: string` meaning
it must be of type `string`. The colon ":" goes at the end of the parameter then
a space and finally the type annotation.

Breaking it down we have:

- `name` the parameter
- `:` the character used to indicate the type annotation
- `string` the actual type

## Exercises

### 1 - Write Your Own

Now it's your turn. Write a function called `sum` which takes in two
parameters, `a` and `b` both of which are type `number`. The function should
return `a + b`.

```typescript
function () {}
```

### 2 - In The Wild

Time to see parameter type annotations out in the wild! Look on GitHub/GitLab
for an OSS project that has an example of this and then paste the link below.

Link:

### 3 - Meta

Hopefully you're not scared of large codebases! Go to the [TypeScript
repo](https://github.com/microsoft/TypeScript) and find an example of
parameter type annotations and paste the link below.

Link:

## Quiz

Q1: Do parameters always need to be annotated?
A1:

Q2: Type annotations are defined using what single character?
A2:

Q3: What is the type for the parameter used in the `helloWorld` example?
A3:

## Reflection

Pretend your talking to a high school student taking computer science.
Explain "parameter type annotations" to them.

## Verify

Let's verify your exercises and quiz answers. From the terminal, run:

```sh
# Make sure you're in the same directory as this file
# `basics-of-typescript/01-read-typescript`
# You can print the current directory with:
pwd

# If you're not, run this
`cd 01-read-typescript`

# Run the tests with the file number - 01
sh test.sh 01
```
