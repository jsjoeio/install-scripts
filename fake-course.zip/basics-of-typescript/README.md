# Basics of TypeScript

A course teaching you the basics of TypeScript

## Outline

- What is TypeScript - Module 0
- How to read TypeScript
  - Annotations
    - Show function (parameter, return) + variable + optional prop
  - Declaration Files
    - @types - DefinitelyTyped
    - index.d.ts - Projects that include them
- How to set up a Node/TypeScript project
  - Start → Finish incl. testing with Jest
  - tsconfig
- How to write TypeScript
  - Convert small OSS project ([1](https://github.com/jarofghosts/dotpather) or [2](https://github.com/jarofghosts/just-pluck) to TS)
- Resources for working with TypeScript regularly
  - TypeScript Repo, StackOverflow, TypeScript Playground
  - TypeScript Discord, TypeScript Cheatsheets

## Notes

- How much to teach?
- Examples?
  - Get them from popular open-source projects
- Post-course challenges
  - Answer 2 questions on Stack Overflow
  - Contribute to TypeScript Open Source

Use the Two-tter technique

### Testing

- Jest + TS
- [tsd](https://github.com/SamVerschueren/tsd#readme) writing tests for your types 😮
