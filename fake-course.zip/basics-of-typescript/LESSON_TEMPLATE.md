- lesson: the concept you're learning
- exercise: hands-on practice
- quiz: verify what you learned
- reflection: remember what you learn

# Lesson:

## Exercises

## Quiz

## Reflection

## Verify
